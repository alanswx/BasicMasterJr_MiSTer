/*
	�����x�[�V�b�N�}�X�^�[Jr.�G�~�����[�^
	����
*/

#include <stdio.h>
#include <string.h>
#include "bm2.h"

static uint8 lastWriteVol = 0x80;	/* �Ō�ɏo�͂����l */

/*
	�X�s�[�J�ɏo�͂���
*/
void writeVolume(struct Bm2stat *bm2, uint8 vol)
{
	unsigned int pos, off;

	lastWriteVol = vol;

	pos = bm2->cpu_freq / bm2->io_freq - bm2->cpu.states;
	if(pos & 0x80000000)
		return;
	else if(pos & 0xf0000000)
		off = 44100 * (pos >> 16) / (bm2->cpu_freq >> 16);
	else if(pos & 0xff000000)
		off = 44100 * (pos >> 12) / (bm2->cpu_freq >> 12);
	else if(pos & 0xfff00000)
		off = 44100 * (pos >> 8) / (bm2->cpu_freq >> 8);
	else if(pos & 0xffff0000)
		off = 44100 * (pos >> 4) / (bm2->cpu_freq >> 4);
	else
		off = 44100 * pos / bm2->cpu_freq;
	if(off < bm2->sound_sample_size)
		memset(bm2->sound_write_pointer + off, (int )vol / 2, bm2->sound_sample_size - off);
}

/*
	�T�E���h�o�b�t�@�̑傫�������߂�
*/
int getSoundSampleSize(int io_freq)
{
	int sample_size;

	for(sample_size = 0x40000000; sample_size != 1 && 44100 / sample_size <= io_freq; sample_size >>= 1)
		;

	return sample_size;
}

/*
	�ǂݍ��݃o�b�t�@�Ə������݃o�b�t�@�����ւ���
*/
void flipSoundBuffer(struct Bm2stat *bm2)
{
	uint8 *next_write_pointer;

	next_write_pointer = bm2->sound_write_pointer + bm2->sound_sample_size;
	if(next_write_pointer >= bm2->sound_buffer + bm2->sound_buffer_size)
		next_write_pointer = bm2->sound_buffer;
	if(bm2->sound_read_pointer <= next_write_pointer && next_write_pointer < bm2->sound_read_pointer + bm2->sound_sample_size)
		return;
	bm2->sound_write_pointer = next_write_pointer;

	lastWriteVol = lastWriteVol / 2;
	memset(bm2->sound_write_pointer, lastWriteVol, bm2->sound_sample_size);

#if 0
	{
		uint8 buf[bm2->sound_sample_size], *p;
		int8 *q;

		for(p = buf, q = bm2->sound_read_pointer; p < buf + bm2->sound_sample_size; p++, q++) {
			*p = (int )*q + 128;
		}
		appendWave("sound.wav", buf, bm2->sound_sample_size);
	}
#endif
}

/*
	Copyright 2008, 2014 maruhiro
	All rights reserved. 

	Redistribution and use in source and binary forms, 
	with or without modification, are permitted provided that 
	the following conditions are met: 

	 1. Redistributions of source code must retain the above copyright notice, 
	    this list of conditions and the following disclaimer. 

	 2. Redistributions in binary form must reproduce the above copyright notice, 
	    this list of conditions and the following disclaimer in the documentation 
	    and/or other materials provided with the distribution. 

	THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
	INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
	FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
	THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
	SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* eof */
