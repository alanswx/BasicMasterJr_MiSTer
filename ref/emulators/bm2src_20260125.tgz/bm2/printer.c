/*
	日立ベーシックマスターJr.エミュレータ
	ラインプリンタ
*/

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "bm2.h"

/*
	文字コード変換 00～1F
*/
const static uint8 *conv_ctrl[2][0x20] = {
	{
		/* Shift-JIS */
		(const uint8 *)"\x20",	/* 00 */
		(const uint8 *)"\x20",	/* 01 */
		(const uint8 *)"\x20",	/* 02 */
		(const uint8 *)"\x20",	/* 03 */
		(const uint8 *)"\x20",	/* 04 */
		(const uint8 *)"\x20",	/* 05 */
		(const uint8 *)"\x20",	/* 06 */
		(const uint8 *)"\x20",	/* 07 */
		(const uint8 *)"\x20",	/* 08 */
		(const uint8 *)"\x20",	/* 09 */
#ifdef O_BINARY
		(const uint8 *)"\x0d\x0a",	/* 0a CRLF */
#else
		(const uint8 *)"\x0a",	/* 0a LF */
#endif
		(const uint8 *)"\x20",	/* 0b */
		(const uint8 *)"\x20",	/* 0c */
		(const uint8 *)"\x20",	/* 0d */
		(const uint8 *)"\x20",	/* 0e */
		(const uint8 *)"\x20",	/* 0f */
		(const uint8 *)"\x20",	/* 10 */
		(const uint8 *)"\x20",	/* 11 */
		(const uint8 *)"\x20",	/* 12 */
		(const uint8 *)"\x20",	/* 13 */
		(const uint8 *)"\x20",	/* 14 */
		(const uint8 *)"\x20",	/* 15 */
		(const uint8 *)"\x20",	/* 16 */
		(const uint8 *)"\x20",	/* 17 */
		(const uint8 *)"\x20",	/* 18 */
		(const uint8 *)"\x20",	/* 19 */
		(const uint8 *)"\x20",	/* 1a */
		(const uint8 *)"\x20",	/* 1b */
		(const uint8 *)"\x81\xa8",	/* 1c → */
		(const uint8 *)"\x81\xa9",	/* 1d ← */
		(const uint8 *)"\x81\xaa",	/* 1e ↑ */
		(const uint8 *)"\x81\xab"	/* 1f ↓ */
	}, {
		/* UTF-8 */
		(const uint8 *)"\x20",	/* 00 */
		(const uint8 *)"\x20",	/* 01 */
		(const uint8 *)"\x20",	/* 02 */
		(const uint8 *)"\x20",	/* 03 */
		(const uint8 *)"\x20",	/* 04 */
		(const uint8 *)"\x20",	/* 05 */
		(const uint8 *)"\x20",	/* 06 */
		(const uint8 *)"\x20",	/* 07 */
		(const uint8 *)"\x20",	/* 08 */
		(const uint8 *)"\x20",	/* 09 */
#ifdef O_BINARY
		(const uint8 *)"\x0d\x0a",	/* 0a CRLF */
#else
		(const uint8 *)"\x0a",	/* 0a LF */
#endif
		(const uint8 *)"\x20",	/* 0b */
		(const uint8 *)"\x20",	/* 0c */
		(const uint8 *)"\x20",	/* 0d */
		(const uint8 *)"\x20",	/* 0e */
		(const uint8 *)"\x20",	/* 0f */
		(const uint8 *)"\x20",	/* 10 */
		(const uint8 *)"\x20",	/* 11 */
		(const uint8 *)"\x20",	/* 12 */
		(const uint8 *)"\x20",	/* 13 */
		(const uint8 *)"\x20",	/* 14 */
		(const uint8 *)"\x20",	/* 15 */
		(const uint8 *)"\x20",	/* 16 */
		(const uint8 *)"\x20",	/* 17 */
		(const uint8 *)"\x20",	/* 18 */
		(const uint8 *)"\x20",	/* 19 */
		(const uint8 *)"\x20",	/* 1a */
		(const uint8 *)"\x20",	/* 1b */
		(const uint8 *)"\xe2\x86\x92",	/* 1c → */
		(const uint8 *)"\xe2\x86\x90",	/* 1d ← */
		(const uint8 *)"\xe2\x86\x91",	/* 1e ↑ */
		(const uint8 *)"\xe2\x86\x93"	/* 1f ↓ */
	}
};

/*
	文字コード変換 80～FF (SO)
*/
const static uint8 *conv_so[2][0x80] = {
	{
		/* Shift-JIS */
		(const uint8 *)"\x20",	/* 80 */
		(const uint8 *)"\x20",	/* 81 */
		(const uint8 *)"\x20",	/* 82 */
		(const uint8 *)"\x20",	/* 83 */
		(const uint8 *)"\x20",	/* 84 */
		(const uint8 *)"\x20",	/* 85 */
		(const uint8 *)"\x20",	/* 86 */
		(const uint8 *)"\x20",	/* 87 */
		(const uint8 *)"\x20",	/* 88 */
		(const uint8 *)"\x20",	/* 89 */
		(const uint8 *)"\x20",	/* 8a */
		(const uint8 *)"\x20",	/* 8b */
		(const uint8 *)"\x20",	/* 8c */
		(const uint8 *)"\x20",	/* 8d */
		(const uint8 *)"\x20",	/* 8e */
		(const uint8 *)"\x84\xa9",	/* 8f ┼ */
		(const uint8 *)"\x84\xa8",	/* 90 ┴ */
		(const uint8 *)"\x84\xa6",	/* 91 ┬ */
		(const uint8 *)"\x84\xa7",	/* 92 ┤ */
		(const uint8 *)"\x84\xa5",	/* 93 ├ */
		(const uint8 *)"\x81\x50",	/* 94 ￣ */
		(const uint8 *)"\x84\x9f",	/* 95 ─ */
		(const uint8 *)"\x84\xa0",	/* 96 │ */
		(const uint8 *)"\x20",	/* 97 */
		(const uint8 *)"\x84\xa1",	/* 98 ┌ */
		(const uint8 *)"\x84\xa2",	/* 99 ┐ */
		(const uint8 *)"\x84\xa4",	/* 9a └ */
		(const uint8 *)"\x84\xa3",	/* 9b ┘ */
		(const uint8 *)"\x20",	/* 9c */
		(const uint8 *)"\x20",	/* 9d */
		(const uint8 *)"\x20",	/* 9e */
		(const uint8 *)"\x20",	/* 9f */
		(const uint8 *)"\x81\xa7",	/* a0 〒 */
		(const uint8 *)"\xa1",	/* a1 。 */
		(const uint8 *)"\xa2",	/* a2 「 */
		(const uint8 *)"\xa3",	/* a3 」 */
		(const uint8 *)"\xa4",	/* a4 、 */
		(const uint8 *)"\xa5",	/* a5 ・ */
		(const uint8 *)"\xa6",	/* a6 ヲ */
		(const uint8 *)"\xa7",	/* a7 ァ */
		(const uint8 *)"\xa8",	/* a8 ィ */
		(const uint8 *)"\xa9",	/* a9 ゥ */
		(const uint8 *)"\xaa",	/* aa ェ */
		(const uint8 *)"\xab",	/* ab ォ */
		(const uint8 *)"\xac",	/* ac ャ */
		(const uint8 *)"\xad",	/* ad ュ */
		(const uint8 *)"\xae",	/* ae ョ */
		(const uint8 *)"\xaf",	/* af ッ */
		(const uint8 *)"\xb0",	/* b0 ー */
		(const uint8 *)"\xb1",	/* b1 ア */
		(const uint8 *)"\xb2",	/* b2 イ */
		(const uint8 *)"\xb3",	/* b3 ウ */
		(const uint8 *)"\xb4",	/* b4 エ */
		(const uint8 *)"\xb5",	/* b5 オ */
		(const uint8 *)"\xb6",	/* b6 カ */
		(const uint8 *)"\xb7",	/* b7 キ */
		(const uint8 *)"\xb8",	/* b8 ク */
		(const uint8 *)"\xb9",	/* b9 ケ */
		(const uint8 *)"\xba",	/* ba コ */
		(const uint8 *)"\xbb",	/* bb サ */
		(const uint8 *)"\xbc",	/* bc シ */
		(const uint8 *)"\xbd",	/* bd ス */
		(const uint8 *)"\xbe",	/* be セ */
		(const uint8 *)"\xbf",	/* bf ソ */
		(const uint8 *)"\xc0",	/* c0 タ */
		(const uint8 *)"\xc1",	/* c1 チ */
		(const uint8 *)"\xc2",	/* c2 ツ */
		(const uint8 *)"\xc3",	/* c3 テ */
		(const uint8 *)"\xc4",	/* c4 ト */
		(const uint8 *)"\xc5",	/* c5 ナ */
		(const uint8 *)"\xc6",	/* c6 ニ */
		(const uint8 *)"\xc7",	/* c7 ヌ */
		(const uint8 *)"\xc8",	/* c8 ネ */
		(const uint8 *)"\xc9",	/* c9 ノ */
		(const uint8 *)"\xca",	/* ca ハ */
		(const uint8 *)"\xcb",	/* cb ヒ */
		(const uint8 *)"\xcc",	/* cc フ */
		(const uint8 *)"\xcd",	/* cd ヘ */
		(const uint8 *)"\xce",	/* ce ホ */
		(const uint8 *)"\xcf",	/* cf マ */
		(const uint8 *)"\xd0",	/* d0 ミ */
		(const uint8 *)"\xd1",	/* d1 ム */
		(const uint8 *)"\xd2",	/* d2 メ */
		(const uint8 *)"\xd3",	/* d3 モ */
		(const uint8 *)"\xd4",	/* d4 ヤ */
		(const uint8 *)"\xd5",	/* d5 ユ */
		(const uint8 *)"\xd6",	/* d6 ヨ */
		(const uint8 *)"\xd7",	/* d7 ラ */
		(const uint8 *)"\xd8",	/* d8 リ */
		(const uint8 *)"\xd9",	/* d9 ル */
		(const uint8 *)"\xda",	/* da レ */
		(const uint8 *)"\xdb",	/* db ロ */
		(const uint8 *)"\xdc",	/* dc ワ */
		(const uint8 *)"\xdd",	/* dd ン */
		(const uint8 *)"\xde",	/* de ゛ */
		(const uint8 *)"\xdf",	/* df ゜ */
		(const uint8 *)"\x20",	/* e0 */
		(const uint8 *)"\x84\xba",	/* e1 */
		(const uint8 *)"\x84\xb9",	/* e2 */
		(const uint8 *)"\x84\xbc",	/* e3 */
		(const uint8 *)"\x20",	/* e4 */
		(const uint8 *)"\x20",	/* e5 */
		(const uint8 *)"\x20",	/* e6 */
		(const uint8 *)"\x20",	/* e7 */
		(const uint8 *)"\x20",	/* e8 */
		(const uint8 *)"\x20",	/* e9 */
		(const uint8 *)"\x20",	/* ea */
		(const uint8 *)"\x20",	/* eb */
		(const uint8 *)"\x81\x9c",	/* ec ● */
		(const uint8 *)"\x81\x9b",	/* ed ○ */
		(const uint8 *)"\x20",	/* ee */
		(const uint8 *)"\x20",	/* ef */
		(const uint8 *)"\x20",	/* f0 */
		(const uint8 *)"\x89\x7e",	/* f1 円 */
		(const uint8 *)"\x94\x4e",	/* f2 年 */
		(const uint8 *)"\x8c\x8e",	/* f3 月 */
		(const uint8 *)"\x93\xfa",	/* f4 日 */
		(const uint8 *)"\x8e\x9e",	/* f5 時 */
		(const uint8 *)"\x95\xaa",	/* f6 分 */
		(const uint8 *)"\x95\x62",	/* f7 秒 */
		(const uint8 *)"\x20",	/* f8 */
		(const uint8 *)"\x20",	/* f9 */
		(const uint8 *)"\x20",	/* fa */
		(const uint8 *)"\x81\xf4",	/* fb ♪ */
		(const uint8 *)"\x81\x80",	/* fc ÷ */
		(const uint8 *)"\x81\x7d",	/* fd ± */
		(const uint8 *)"\x20",	/* fe */
		(const uint8 *)"\x20"	/* ff */
	}, {
		/* UTF-8 */
		(const uint8 *)"\x20",	/* 80   */
		(const uint8 *)"\xe2\x96\x81",	/* 81 ▁ */
		(const uint8 *)"\xe2\x96\x82",	/* 82 ▂ */
		(const uint8 *)"\xe2\x96\x83",	/* 83 ▃ */
		(const uint8 *)"\xe2\x96\x84",	/* 84 ▄ */
		(const uint8 *)"\xe2\x96\x85",	/* 85 ▅ */
		(const uint8 *)"\xe2\x96\x86",	/* 86 ▆ */
		(const uint8 *)"\xe2\x96\x87",	/* 87 ▇ */
		(const uint8 *)"\xe2\x96\x8f",	/* 88 ▏ */
		(const uint8 *)"\xe2\x96\x8e",	/* 89 ▎ */
		(const uint8 *)"\xe2\x96\x8d",	/* 8a ▍ */
		(const uint8 *)"\xe2\x96\x8c",	/* 8b ▌ */
		(const uint8 *)"\xe2\x96\x8b",	/* 8c ▋ */
		(const uint8 *)"\xe2\x96\x8a",	/* 8d ▊ */
		(const uint8 *)"\xe2\x96\x89",	/* 8e ▉ */
		(const uint8 *)"\xe2\x94\xbc",	/* 8f ┼ */
		(const uint8 *)"\xe2\x94\xb4",	/* 90 ┴ */
		(const uint8 *)"\xe2\x94\xac",	/* 91 ┬ */
		(const uint8 *)"\xe2\x94\xa4",	/* 92 ┤ */
		(const uint8 *)"\xe2\x94\x9c",	/* 93 ├ */
		(const uint8 *)"\xef\xbf\xa3",	/* 94 ￣ */
		(const uint8 *)"\xe2\x94\x80",	/* 95 ─ */
		(const uint8 *)"\xe2\x94\x82",	/* 96 │ */
		(const uint8 *)"\xe2\x96\x95",	/* 97 ▕ */
		(const uint8 *)"\xe2\x94\x8c",	/* 98 ┌ */
		(const uint8 *)"\xe2\x94\x90",	/* 99 ┐ */
		(const uint8 *)"\xe2\x94\x94",	/* 9a └ */
		(const uint8 *)"\xe2\x94\x98",	/* 9b ┘ */
		(const uint8 *)"\xe2\x95\xad",	/* 9c ╭ */
		(const uint8 *)"\xe2\x95\xae",	/* 9d ╮ */
		(const uint8 *)"\xe2\x95\xb0",	/* 9e ╰ */
		(const uint8 *)"\xe2\x95\xaf",	/* 9f ╯ */
		(const uint8 *)"\xe3\x80\x92",	/* a0 〒 */
		(const uint8 *)"\xef\xbd\xa1",	/* a1 。 */
		(const uint8 *)"\xef\xbd\xa2",	/* a2 「 */
		(const uint8 *)"\xef\xbd\xa3",	/* a3 」 */
		(const uint8 *)"\xef\xbd\xa4",	/* a4 、 */
		(const uint8 *)"\xef\xbd\xa5",	/* a5 ・ */
		(const uint8 *)"\xef\xbd\xa6",	/* a6 ヲ */
		(const uint8 *)"\xef\xbd\xa7",	/* a7 ァ */
		(const uint8 *)"\xef\xbd\xa8",	/* a8 ィ */
		(const uint8 *)"\xef\xbd\xa9",	/* a9 ゥ */
		(const uint8 *)"\xef\xbd\xaa",	/* aa ェ */
		(const uint8 *)"\xef\xbd\xab",	/* ab ォ */
		(const uint8 *)"\xef\xbd\xac",	/* ac ャ */
		(const uint8 *)"\xef\xbd\xad",	/* ad ュ */
		(const uint8 *)"\xef\xbd\xae",	/* ae ョ */
		(const uint8 *)"\xef\xbd\xaf",	/* af ッ */
		(const uint8 *)"\xef\xbd\xb0",	/* b0 ー */
		(const uint8 *)"\xef\xbd\xb1",	/* b1 ア */
		(const uint8 *)"\xef\xbd\xb2",	/* b2 イ */
		(const uint8 *)"\xef\xbd\xb3",	/* b3 ウ */
		(const uint8 *)"\xef\xbd\xb4",	/* b4 エ */
		(const uint8 *)"\xef\xbd\xb5",	/* b5 オ */
		(const uint8 *)"\xef\xbd\xb6",	/* b6 カ */
		(const uint8 *)"\xef\xbd\xb7",	/* b7 キ */
		(const uint8 *)"\xef\xbd\xb8",	/* b8 ク */
		(const uint8 *)"\xef\xbd\xb9",	/* b9 ケ */
		(const uint8 *)"\xef\xbd\xba",	/* ba コ */
		(const uint8 *)"\xef\xbd\xbb",	/* bb サ */
		(const uint8 *)"\xef\xbd\xbc",	/* bc シ */
		(const uint8 *)"\xef\xbd\xbd",	/* bd ス */
		(const uint8 *)"\xef\xbd\xbe",	/* be セ */
		(const uint8 *)"\xef\xbd\xbf",	/* bf ソ */
		(const uint8 *)"\xef\xbe\x80",	/* c0 タ */
		(const uint8 *)"\xef\xbe\x81",	/* c1 チ */
		(const uint8 *)"\xef\xbe\x82",	/* c2 ツ */
		(const uint8 *)"\xef\xbe\x83",	/* c3 テ */
		(const uint8 *)"\xef\xbe\x84",	/* c4 ト */
		(const uint8 *)"\xef\xbe\x85",	/* c5 ナ */
		(const uint8 *)"\xef\xbe\x86",	/* c6 ニ */
		(const uint8 *)"\xef\xbe\x87",	/* c7 ヌ */
		(const uint8 *)"\xef\xbe\x88",	/* c8 ネ */
		(const uint8 *)"\xef\xbe\x89",	/* c9 ノ */
		(const uint8 *)"\xef\xbe\x8a",	/* ca ハ */
		(const uint8 *)"\xef\xbe\x8b",	/* cb ヒ */
		(const uint8 *)"\xef\xbe\x8c",	/* cc フ */
		(const uint8 *)"\xef\xbe\x8d",	/* cd ヘ */
		(const uint8 *)"\xef\xbe\x8e",	/* ce ホ */
		(const uint8 *)"\xef\xbe\x8f",	/* cf マ */
		(const uint8 *)"\xef\xbe\x90",	/* d0 ミ */
		(const uint8 *)"\xef\xbe\x91",	/* d1 ム */
		(const uint8 *)"\xef\xbe\x92",	/* d2 メ */
		(const uint8 *)"\xef\xbe\x93",	/* d3 モ */
		(const uint8 *)"\xef\xbe\x94",	/* d4 ヤ */
		(const uint8 *)"\xef\xbe\x95",	/* d5 ユ */
		(const uint8 *)"\xef\xbe\x96",	/* d6 ヨ */
		(const uint8 *)"\xef\xbe\x97",	/* d7 ラ */
		(const uint8 *)"\xef\xbe\x98",	/* d8 リ */
		(const uint8 *)"\xef\xbe\x99",	/* d9 ル */
		(const uint8 *)"\xef\xbe\x9a",	/* da レ */
		(const uint8 *)"\xef\xbe\x9b",	/* db ロ */
		(const uint8 *)"\xef\xbe\x9c",	/* dc ワ */
		(const uint8 *)"\xef\xbe\x9d",	/* dd ン */
		(const uint8 *)"\xef\xbe\x9e",	/* de ゛ */
		(const uint8 *)"\xef\xbe\x9f",	/* df ゜ */
		(const uint8 *)"\xe2\x95\x90",	/* e0 ═ */
		(const uint8 *)"\xe2\x95\x9e",	/* e1 ╞ */
		(const uint8 *)"\xe2\x95\xaa",	/* e2 ╪ */
		(const uint8 *)"\xe2\x95\xa1",	/* e3 ╡ */
		(const uint8 *)"\xe2\x97\xa4",	/* e4 ◤ */
		(const uint8 *)"\xe2\x97\xa5",	/* e5 ◥ */
		(const uint8 *)"\xe2\x97\xa3",	/* e6 ◣ */
		(const uint8 *)"\xe2\x97\xa2",	/* e7 ◢ */
		(const uint8 *)"\xe2\x99\xa0",	/* e8 ♠ */
		(const uint8 *)"\xe2\x99\xa5",	/* e9 ♥ */
		(const uint8 *)"\xe2\x99\xa6",	/* ea ♦ */
		(const uint8 *)"\xe2\x99\xa3",	/* eb ♣ */
		(const uint8 *)"\xe2\x97\x8f",	/* ec ● */
		(const uint8 *)"\xe2\x97\x8b",	/* ed ○ */
		(const uint8 *)"\xe2\x95\xb1",	/* ee ╱ */
		(const uint8 *)"\xe2\x95\xb2",	/* ef ╲ */
		(const uint8 *)"\xe2\x95\xb3",	/* f0 ╳ */
		(const uint8 *)"\xe5\x86\x86",	/* f1 円 */
		(const uint8 *)"\xe5\xb9\xb4",	/* f2 年 */
		(const uint8 *)"\xe6\x9c\x88",	/* f3 月 */
		(const uint8 *)"\xe6\x97\xa5",	/* f4 日 */
		(const uint8 *)"\xe6\x99\x82",	/* f5 時 */
		(const uint8 *)"\xe5\x88\x86",	/* f6 分 */
		(const uint8 *)"\xe7\xa7\x92",	/* f7 秒 */
		(const uint8 *)"\xe2\x95\x8b",	/* f8 ╋ */
		(const uint8 *)"\xe2\x8b\x80",	/* f9 ⋀ */
		(const uint8 *)"\xe2\x8b\x81",	/* fa ⋁ */
		(const uint8 *)"\xe2\x99\xaa",	/* fb ♪ */
		(const uint8 *)"\xc3\xb7",	/* fc ÷ */
		(const uint8 *)"\xc2\xb1",	/* fd ± */
		(const uint8 *)"\xe2\x96\x91",	/* fe ░ */
		(const uint8 *)"\x20"	/* ff */
	}
};

/*
	文字コード変換 80～FF (SI)
*/
const static uint8 *conv_si[2][0x80] = {
	{
		/* Shift-JIS */
		(const uint8 *)"\x94\x4e",	/* 80 年 */
		(const uint8 *)"\x8c\x8e",	/* 81 月 */
		(const uint8 *)"\x93\xfa",	/* 82 日 */
		(const uint8 *)"\x8e\x73",	/* 83 市 */
		(const uint8 *)"\x8b\xe6",	/* 84 区 */
		(const uint8 *)"\x92\xac",	/* 85 町 */
		(const uint8 *)"\x82\xf0",	/* 86 を */
		(const uint8 *)"\x82\x9f",	/* 87 ぁ */
		(const uint8 *)"\x82\xa1",	/* 88 ぃ */
		(const uint8 *)"\x82\xa3",	/* 89 ぅ */
		(const uint8 *)"\x82\xa5",	/* 8a ぇ */
		(const uint8 *)"\x82\xa7",	/* 8b ぉ */
		(const uint8 *)"\x82\xe1",	/* 8c ゃ */
		(const uint8 *)"\x82\xe3",	/* 8d ゅ */
		(const uint8 *)"\x82\xe5",	/* 8e ょ */
		(const uint8 *)"\x82\xc1",	/* 8f っ */
		(const uint8 *)"\x83\xce",	/* 90 π */
		(const uint8 *)"\x82\xa0",	/* 91 あ */
		(const uint8 *)"\x82\xa2",	/* 92 い */
		(const uint8 *)"\x82\xa4",	/* 93 う */
		(const uint8 *)"\x82\xa6",	/* 94 え */
		(const uint8 *)"\x82\xa8",	/* 95 お */
		(const uint8 *)"\x82\xa9",	/* 96 か */
		(const uint8 *)"\x82\xab",	/* 97 き */
		(const uint8 *)"\x82\xad",	/* 98 く */
		(const uint8 *)"\x82\xaf",	/* 99 け */
		(const uint8 *)"\x82\xb1",	/* 9a こ */
		(const uint8 *)"\x82\xb3",	/* 9b さ */
		(const uint8 *)"\x82\xb5",	/* 9c し */
		(const uint8 *)"\x82\xb7",	/* 9d す */
		(const uint8 *)"\x82\xb9",	/* 9e せ */
		(const uint8 *)"\x82\xbb",	/* 9f そ */
		(const uint8 *)"\x81\xa7",	/* a0 〒 */
		(const uint8 *)"\xa1",	/* a1 。 */
		(const uint8 *)"\xa2",	/* a2 「 */
		(const uint8 *)"\xa3",	/* a3 」 */
		(const uint8 *)"\xa4",	/* a4 、 */
		(const uint8 *)"\xa5",	/* a5 ・ */
		(const uint8 *)"\xa6",	/* a6 ヲ */
		(const uint8 *)"\xa7",	/* a7 ァ */
		(const uint8 *)"\xa8",	/* a8 ィ */
		(const uint8 *)"\xa9",	/* a9 ゥ */
		(const uint8 *)"\xaa",	/* aa ェ */
		(const uint8 *)"\xab",	/* ab ォ */
		(const uint8 *)"\xac",	/* ac ャ */
		(const uint8 *)"\xad",	/* ad ュ */
		(const uint8 *)"\xae",	/* ae ョ */
		(const uint8 *)"\xaf",	/* af ッ */
		(const uint8 *)"\xb0",	/* b0 ー */
		(const uint8 *)"\xb1",	/* b1 ア */
		(const uint8 *)"\xb2",	/* b2 イ */
		(const uint8 *)"\xb3",	/* b3 ウ */
		(const uint8 *)"\xb4",	/* b4 エ */
		(const uint8 *)"\xb5",	/* b5 オ */
		(const uint8 *)"\xb6",	/* b6 カ */
		(const uint8 *)"\xb7",	/* b7 キ */
		(const uint8 *)"\xb8",	/* b8 ク */
		(const uint8 *)"\xb9",	/* b9 ケ */
		(const uint8 *)"\xba",	/* ba コ */
		(const uint8 *)"\xbb",	/* bb サ */
		(const uint8 *)"\xbc",	/* bc シ */
		(const uint8 *)"\xbd",	/* bd ス */
		(const uint8 *)"\xbe",	/* be セ */
		(const uint8 *)"\xbf",	/* bf ソ */
		(const uint8 *)"\xc0",	/* c0 タ */
		(const uint8 *)"\xc1",	/* c1 チ */
		(const uint8 *)"\xc2",	/* c2 ツ */
		(const uint8 *)"\xc3",	/* c3 テ */
		(const uint8 *)"\xc4",	/* c4 ト */
		(const uint8 *)"\xc5",	/* c5 ナ */
		(const uint8 *)"\xc6",	/* c6 ニ */
		(const uint8 *)"\xc7",	/* c7 ヌ */
		(const uint8 *)"\xc8",	/* c8 ネ */
		(const uint8 *)"\xc9",	/* c9 ノ */
		(const uint8 *)"\xca",	/* ca ハ */
		(const uint8 *)"\xcb",	/* cb ヒ */
		(const uint8 *)"\xcc",	/* cc フ */
		(const uint8 *)"\xcd",	/* cd ヘ */
		(const uint8 *)"\xce",	/* ce ホ */
		(const uint8 *)"\xcf",	/* cf マ */
		(const uint8 *)"\xd0",	/* d0 ミ */
		(const uint8 *)"\xd1",	/* d1 ム */
		(const uint8 *)"\xd2",	/* d2 メ */
		(const uint8 *)"\xd3",	/* d3 モ */
		(const uint8 *)"\xd4",	/* d4 ヤ */
		(const uint8 *)"\xd5",	/* d5 ユ */
		(const uint8 *)"\xd6",	/* d6 ヨ */
		(const uint8 *)"\xd7",	/* d7 ラ */
		(const uint8 *)"\xd8",	/* d8 リ */
		(const uint8 *)"\xd9",	/* d9 ル */
		(const uint8 *)"\xda",	/* da レ */
		(const uint8 *)"\xdb",	/* db ロ */
		(const uint8 *)"\xdc",	/* dc ワ */
		(const uint8 *)"\xdd",	/* dd ン */
		(const uint8 *)"\xde",	/* de ゛ */
		(const uint8 *)"\xdf",	/* df ゜ */
		(const uint8 *)"\x82\xbd",	/* d0 た */
		(const uint8 *)"\x82\xbf",	/* d1 ち */
		(const uint8 *)"\x82\xc2",	/* d2 つ */
		(const uint8 *)"\x82\xc4",	/* d3 て */
		(const uint8 *)"\x82\xc6",	/* d4 と */
		(const uint8 *)"\x82\xc8",	/* d5 な */
		(const uint8 *)"\x82\xc9",	/* d6 に */
		(const uint8 *)"\x82\xca",	/* d7 ぬ */
		(const uint8 *)"\x82\xcb",	/* d8 ね */
		(const uint8 *)"\x82\xcc",	/* d9 の */
		(const uint8 *)"\x82\xcd",	/* da は */
		(const uint8 *)"\x82\xd0",	/* db ひ */
		(const uint8 *)"\x82\xd3",	/* dc ふ */
		(const uint8 *)"\x82\xd6",	/* dd へ */
		(const uint8 *)"\x82\xd9",	/* de ほ */
		(const uint8 *)"\x82\xdc",	/* df ま */
		(const uint8 *)"\x82\xdd",	/* f0 み */
		(const uint8 *)"\x82\xde",	/* f1 む */
		(const uint8 *)"\x82\xdf",	/* f2 め */
		(const uint8 *)"\x83\xe0",	/* f3 も */
		(const uint8 *)"\x83\xe2",	/* f4 や */
		(const uint8 *)"\x83\xe4",	/* f5 ゆ */
		(const uint8 *)"\x83\xe6",	/* f6 よ */
		(const uint8 *)"\x83\xe7",	/* f7 ら */
		(const uint8 *)"\x83\xe8",	/* f8 り */
		(const uint8 *)"\x83\xe9",	/* f9 る */
		(const uint8 *)"\x83\xea",	/* fa れ */
		(const uint8 *)"\x83\xeb",	/* fb ろ */
		(const uint8 *)"\x83\xed",	/* fc わ */
		(const uint8 *)"\x82\xf1",	/* fd ん */
		(const uint8 *)"\x20",	/* fe */
		(const uint8 *)"\x20"	/* ff */
	}, {
		/* UTF-8 */
		(const uint8 *)"\xe5\xb9\xb4",	/* 80 年 */
		(const uint8 *)"\xe6\x9c\x88",	/* 81 月 */
		(const uint8 *)"\xe6\x97\xa5",	/* 82 日 */
		(const uint8 *)"\xe5\xb8\x82",	/* 83 市 */
		(const uint8 *)"\xe5\x8c\xba",	/* 84 区 */
		(const uint8 *)"\xe7\x94\xba",	/* 85 町 */
		(const uint8 *)"\xe3\x82\x92",	/* 86 を */
		(const uint8 *)"\xe3\x81\x81",	/* 87 ぁ */
		(const uint8 *)"\xe3\x81\x83",	/* 88 ぃ */
		(const uint8 *)"\xe3\x81\x85",	/* 89 ぅ */
		(const uint8 *)"\xe3\x81\x87",	/* 8a ぇ */
		(const uint8 *)"\xe3\x81\x89",	/* 8b ぉ */
		(const uint8 *)"\xe3\x82\x83",	/* 8c ゃ */
		(const uint8 *)"\xe3\x82\x85",	/* 8d ゅ */
		(const uint8 *)"\xe3\x82\x87",	/* 8e ょ */
		(const uint8 *)"\xe3\x81\xa3",	/* 8f っ */
		(const uint8 *)"\xcf\x80\x20",	/* 90 π */
		(const uint8 *)"\xe3\x81\x82",	/* 91 あ */
		(const uint8 *)"\xe3\x81\x84",	/* 92 い */
		(const uint8 *)"\xe3\x81\x86",	/* 93 う */
		(const uint8 *)"\xe3\x81\x88",	/* 94 え */
		(const uint8 *)"\xe3\x81\x8a",	/* 95 お */
		(const uint8 *)"\xe3\x81\x8b",	/* 96 か */
		(const uint8 *)"\xe3\x81\x8d",	/* 97 き */
		(const uint8 *)"\xe3\x81\x8f",	/* 98 く */
		(const uint8 *)"\xe3\x81\x92",	/* 99 け */
		(const uint8 *)"\xe3\x81\x93",	/* 9a こ */
		(const uint8 *)"\xe3\x81\x95",	/* 9b さ */
		(const uint8 *)"\xe3\x81\x97",	/* 9c し */
		(const uint8 *)"\xe3\x81\x99",	/* 9d す */
		(const uint8 *)"\xe3\x81\x9b",	/* 9e せ */
		(const uint8 *)"\xe3\x81\x9d",	/* 9f そ */
		(const uint8 *)"\xe3\x80\x92",	/* a0 〒 */
		(const uint8 *)"\xef\xbd\xa1",	/* a1 。 */
		(const uint8 *)"\xef\xbd\xa2",	/* a2 「 */
		(const uint8 *)"\xef\xbd\xa3",	/* a3 」 */
		(const uint8 *)"\xef\xbd\xa4",	/* a4 、 */
		(const uint8 *)"\xef\xbd\xa5",	/* a5 ・ */
		(const uint8 *)"\xef\xbd\xa6",	/* a6 ヲ */
		(const uint8 *)"\xef\xbd\xa7",	/* a7 ァ */
		(const uint8 *)"\xef\xbd\xa8",	/* a8 ィ */
		(const uint8 *)"\xef\xbd\xa9",	/* a9 ゥ */
		(const uint8 *)"\xef\xbd\xaa",	/* aa ェ */
		(const uint8 *)"\xef\xbd\xab",	/* ab ォ */
		(const uint8 *)"\xef\xbd\xac",	/* ac ャ */
		(const uint8 *)"\xef\xbd\xad",	/* ad ュ */
		(const uint8 *)"\xef\xbd\xae",	/* ae ョ */
		(const uint8 *)"\xef\xbd\xaf",	/* af ッ */
		(const uint8 *)"\xef\xbd\xb0",	/* b0 ー */
		(const uint8 *)"\xef\xbd\xb1",	/* b1 ア */
		(const uint8 *)"\xef\xbd\xb2",	/* b2 イ */
		(const uint8 *)"\xef\xbd\xb3",	/* b3 ウ */
		(const uint8 *)"\xef\xbd\xb4",	/* b4 エ */
		(const uint8 *)"\xef\xbd\xb5",	/* b5 オ */
		(const uint8 *)"\xef\xbd\xb6",	/* b6 カ */
		(const uint8 *)"\xef\xbd\xb7",	/* b7 キ */
		(const uint8 *)"\xef\xbd\xb8",	/* b8 ク */
		(const uint8 *)"\xef\xbd\xb9",	/* b9 ケ */
		(const uint8 *)"\xef\xbd\xba",	/* ba コ */
		(const uint8 *)"\xef\xbd\xbb",	/* bb サ */
		(const uint8 *)"\xef\xbd\xbc",	/* bc シ */
		(const uint8 *)"\xef\xbd\xbd",	/* bd ス */
		(const uint8 *)"\xef\xbd\xbe",	/* be セ */
		(const uint8 *)"\xef\xbd\xbf",	/* bf ソ */
		(const uint8 *)"\xef\xbe\x80",	/* c0 タ */
		(const uint8 *)"\xef\xbe\x81",	/* c1 チ */
		(const uint8 *)"\xef\xbe\x82",	/* c2 ツ */
		(const uint8 *)"\xef\xbe\x83",	/* c3 テ */
		(const uint8 *)"\xef\xbe\x84",	/* c4 ト */
		(const uint8 *)"\xef\xbe\x85",	/* c5 ナ */
		(const uint8 *)"\xef\xbe\x86",	/* c6 ニ */
		(const uint8 *)"\xef\xbe\x87",	/* c7 ヌ */
		(const uint8 *)"\xef\xbe\x88",	/* c8 ネ */
		(const uint8 *)"\xef\xbe\x89",	/* c9 ノ */
		(const uint8 *)"\xef\xbe\x8a",	/* ca ハ */
		(const uint8 *)"\xef\xbe\x8b",	/* cb ヒ */
		(const uint8 *)"\xef\xbe\x8c",	/* cc フ */
		(const uint8 *)"\xef\xbe\x8d",	/* cd ヘ */
		(const uint8 *)"\xef\xbe\x8e",	/* ce ホ */
		(const uint8 *)"\xef\xbe\x8f",	/* cf マ */
		(const uint8 *)"\xef\xbe\x90",	/* d0 ミ */
		(const uint8 *)"\xef\xbe\x91",	/* d1 ム */
		(const uint8 *)"\xef\xbe\x92",	/* d2 メ */
		(const uint8 *)"\xef\xbe\x93",	/* d3 モ */
		(const uint8 *)"\xef\xbe\x94",	/* d4 ヤ */
		(const uint8 *)"\xef\xbe\x95",	/* d5 ユ */
		(const uint8 *)"\xef\xbe\x96",	/* d6 ヨ */
		(const uint8 *)"\xef\xbe\x97",	/* d7 ラ */
		(const uint8 *)"\xef\xbe\x98",	/* d8 リ */
		(const uint8 *)"\xef\xbe\x99",	/* d9 ル */
		(const uint8 *)"\xef\xbe\x9a",	/* da レ */
		(const uint8 *)"\xef\xbe\x9b",	/* db ロ */
		(const uint8 *)"\xef\xbe\x9c",	/* dc ワ */
		(const uint8 *)"\xef\xbe\x9d",	/* dd ン */
		(const uint8 *)"\xef\xbe\x9e",	/* de ゛ */
		(const uint8 *)"\xef\xbe\x9f",	/* df ゜ */
		(const uint8 *)"\xe3\x81\x90",	/* e0 た */
		(const uint8 *)"\xe3\x81\xa1",	/* e1 ち */
		(const uint8 *)"\xe3\x81\xa4",	/* e2 つ */
		(const uint8 *)"\xe3\x81\xa6",	/* e3 て */
		(const uint8 *)"\xe3\x81\xa8",	/* e4 と */
		(const uint8 *)"\xe3\x81\xaa",	/* e5 な */
		(const uint8 *)"\xe3\x81\xab",	/* e6 に */
		(const uint8 *)"\xe3\x81\xac",	/* e7 ぬ */
		(const uint8 *)"\xe3\x81\xad",	/* e8 ね */
		(const uint8 *)"\xe3\x81\xae",	/* e9 の */
		(const uint8 *)"\xe3\x81\xaf",	/* ea は */
		(const uint8 *)"\xe3\x81\xb2",	/* eb ひ */
		(const uint8 *)"\xe3\x81\xb5",	/* ec ふ */
		(const uint8 *)"\xe3\x81\xb8",	/* ed へ */
		(const uint8 *)"\xe3\x81\xbb",	/* ee ほ */
		(const uint8 *)"\xe3\x81\xbe",	/* ef ま */
		(const uint8 *)"\xe3\x81\xbf",	/* f0 み */
		(const uint8 *)"\xe3\x82\x80",	/* f1 む */
		(const uint8 *)"\xe3\x82\x81",	/* f2 め */
		(const uint8 *)"\xe3\x82\x82",	/* f3 も */
		(const uint8 *)"\xe3\x82\x84",	/* f4 や */
		(const uint8 *)"\xe3\x82\x86",	/* f5 ゆ */
		(const uint8 *)"\xe3\x82\x88",	/* f6 よ */
		(const uint8 *)"\xe3\x82\x89",	/* f7 ら */
		(const uint8 *)"\xe3\x82\x8a",	/* f8 り */
		(const uint8 *)"\xe3\x82\x8b",	/* f9 る */
		(const uint8 *)"\xe3\x82\x8c",	/* fa れ */
		(const uint8 *)"\xe3\x82\x8d",	/* fb ろ */
		(const uint8 *)"\xe3\x82\x8f",	/* fc わ */
		(const uint8 *)"\xe3\x82\x93",	/* fd ん */
		(const uint8 *)"\xe2\x96\x91",	/* fe ░ */
		(const uint8 *)"\x20"	/* ff */
	}
};

#ifndef O_BINARY
#define O_BINARY	0
#endif

/*
	ラインプリンタが利用可能かチェックする
*/
int checkLptReady(struct Bm2stat *bm2)
{
	int fd;

	if(bm2->lpt_mode == LPT_MODE_NONE)
		return 0x00;
	if(strlen(bm2->lpt_path) == 0)
		return 0x00;

	if((fd = open(bm2->lpt_path, O_CREAT | O_APPEND | O_WRONLY | O_BINARY, 0664)) < 0)
		return 0x00;
	close(fd);
	return 0x80;
}

/*
	ラインプリンタに1バイト送信する
*/
void sendToLpt(struct Bm2stat *bm2, uint8 c)
{
	int fd;

	if(bm2->lpt_status == 0x00)
		return;
	if(strlen(bm2->lpt_path) == 0)
		return;

	if(bm2->lpt_mode == LPT_MODE_RAW) { /* 無編集 */
		if((fd = open(bm2->lpt_path, O_CREAT | O_APPEND | O_WRONLY | O_BINARY, 0664)) < 0)
			return;
		write(fd, &c, 1);
		close(fd);
	} else { /* 文字コード変換 */
		switch(c) {
		case 0x00: return;	/* NUL */
		case 0x0d: return;	/* CR */
		case 0x0e: bm2->lpt_shift = 0; return;	/* SO */
		case 0x0f: bm2->lpt_shift = 1; return;	/* SI */
		case 0x1b: bm2->lpt_esc = 1; return;	/* ESC */
		}

		if((fd = open(bm2->lpt_path, O_CREAT | O_APPEND | O_WRONLY | O_BINARY, 0664)) < 0)
			return;

		if(bm2->lpt_esc)
			bm2->lpt_esc = 0;
		else {
			if (0x00 <= c && c <= 0x1f)
				write(fd, conv_ctrl[bm2->lpt_mode == LPT_MODE_UTF8][c], strlen((const char *)conv_ctrl[bm2->lpt_mode == LPT_MODE_UTF8][c]));
			else if(0x20 <= c && c <= 0x7f)
				write(fd, &c, 1);
			else if(bm2->lpt_shift)
				write(fd, conv_si[bm2->lpt_mode == LPT_MODE_UTF8][c - 0x80], strlen((const char *)conv_si[bm2->lpt_mode == LPT_MODE_UTF8][c - 0x80]));
			else
				write(fd, conv_so[bm2->lpt_mode == LPT_MODE_UTF8][c - 0x80], strlen((const char *)conv_so[bm2->lpt_mode == LPT_MODE_UTF8][c - 0x80]));
		}

		close(fd);
	}
}

/*
	Copyright 2024 maruhiro
	All rights reserved. 

	Redistribution and use in source and binary forms, 
	with or without modification, are permitted provided that 
	the following conditions are met: 

	 1. Redistributions of source code must retain the above copyright notice, 
	    this list of conditions and the following disclaimer. 

	 2. Redistributions in binary form must reproduce the above copyright notice, 
	    this list of conditions and the following disclaimer in the documentation 
	    and/or other materials provided with the distribution. 

	THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
	INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
	FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
	THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
	SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* eof */
